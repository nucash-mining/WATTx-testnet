WATTx v1.0.0 - Windows 64-bit

A proof-of-stake blockchain with tiered trust scoring for sustainable digital energy.

CONTENTS:
- wattx-qt.exe     - GUI wallet application
- wattx-cli.exe    - Command-line interface
- wattxd.exe       - Daemon/server

QUICK START:
1. Run wattx-qt.exe to start the GUI wallet
2. The wallet will create a data directory at %APPDATA%\WATTx\
3. For testnet, run with: wattx-qt.exe -testnet

TESTNET CONNECTION:
To connect to the existing testnet, add to wattx.conf:
  testnet=1
  addnode=192.168.1.207

For more information, visit the project repository.
